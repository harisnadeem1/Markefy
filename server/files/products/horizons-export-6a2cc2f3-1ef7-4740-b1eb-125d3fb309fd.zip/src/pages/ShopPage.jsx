import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import ProductGrid from '@/components/shop/ProductGrid';
import { allProducts } from '@/data/products';

const ShopPage = () => {
  return (
    <>
      <Helmet>
        <title>All Snippets - CodeSnippets Pro</title>
        <meta name="description" content="Browse our entire collection of high-quality, pre-built code snippets and components for all your project needs." />
        <meta property="og:title" content="All Snippets - CodeSnippets Pro" />
        <meta property="og:description" content="Browse our entire collection of high-quality, pre-built code snippets and components for all your project needs." />
      </Helmet>
      <div className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900">All Code Snippets</h1>
            <p className="mt-4 text-lg text-gray-600">Find the perfect component to elevate your project from our full library.</p>
          </motion.div>
          
          <ProductGrid products={allProducts} />
        </div>
      </div>
    </>
  );
};

export default ShopPage;