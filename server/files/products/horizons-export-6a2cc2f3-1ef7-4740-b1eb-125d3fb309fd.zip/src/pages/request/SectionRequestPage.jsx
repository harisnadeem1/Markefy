import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/use-toast';
import { Lightbulb, Send } from 'lucide-react';

const SectionRequestPage = () => {

    const handleSubmit = (e) => {
        e.preventDefault();
        toast({
            title: "💡 Suggestion Received!",
            description: "Thanks for the great idea! We'll review your suggestion and may add it to our store.",
        });
        e.target.reset();
    };

    return (
        <>
            <Helmet>
                <title>Section Requests & Suggestions - CodeSnippets Pro</title>
                <meta name="description" content="Have an idea for a new code snippet? Let us know! We love getting suggestions from our community." />
            </Helmet>
            <div className="bg-white py-16 sm:py-24 px-4 sm:px-6 lg:px-8">
                <div className="max-w-2xl mx-auto">
                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6 }}
                        className="text-center"
                    >
                        <Lightbulb className="mx-auto h-16 w-16 text-yellow-400" />
                        <h1 className="mt-4 text-4xl sm:text-5xl font-bold text-gray-900 tracking-tight">Have an Idea for a Snippet?</h1>
                        <p className="mt-4 text-xl text-gray-600">
                            We're always looking to grow our library. If there's a component you need that we don't have, let us know!
                        </p>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.2 }}
                        className="mt-16 bg-slate-50 p-8 sm:p-12 rounded-2xl shadow-lg border border-slate-200"
                    >
                        <form onSubmit={handleSubmit} className="space-y-8">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">Your Name</label>
                                <Input id="name" name="name" type="text" required placeholder="Jane Smith" />
                            </div>
                            <div>
                                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">Your Email</label>
                                <Input id="email" name="email" type="email" required placeholder="you@example.com" />
                            </div>
                            <div>
                                <label htmlFor="suggestion" className="block text-sm font-medium text-gray-700 mb-2">Suggestion / Request</label>
                                <Textarea id="suggestion" name="suggestion" required placeholder="Describe the snippet you'd like to see. For example, 'A testimonial slider with avatars on the side' or 'A pricing table with a toggle for monthly/yearly'." rows={6} />
                            </div>
                            <div className="flex justify-end">
                                <Button type="submit" size="lg" className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700">
                                    Submit Idea
                                    <Send className="ml-2 h-4 w-4" />
                                </Button>
                            </div>
                        </form>
                    </motion.div>
                </div>
            </div>
        </>
    );
};

export default SectionRequestPage;