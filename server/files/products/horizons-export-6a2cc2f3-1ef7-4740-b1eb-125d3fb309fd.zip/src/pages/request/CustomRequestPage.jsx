import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from '@/components/ui/use-toast';
import { Send } from 'lucide-react';

const CustomRequestPage = () => {

    const handleSubmit = (e) => {
        e.preventDefault();
        toast({
            title: "🚀 Request Sent!",
            description: "Thank you for your custom request. We'll get back to you within 24 hours.",
        });
        e.target.reset();
    };

    return (
        <>
            <Helmet>
                <title>Custom Website Request - CodeSnippets Pro</title>
                <meta name="description" content="Request a custom-built website tailored to your specific needs. Fill out our form to get a quote." />
            </Helmet>
            <div className="bg-white py-16 sm:py-24 px-4 sm:px-6 lg:px-8">
                <div className="max-w-4xl mx-auto">
                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6 }}
                        className="text-center"
                    >
                        <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 tracking-tight">Need a Full Website?</h1>
                        <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-600">
                            Let us build a stunning, high-performance website for you from the ground up. Tell us about your project to get started.
                        </p>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.2 }}
                        className="mt-16 bg-slate-50 p-8 sm:p-12 rounded-2xl shadow-lg border border-slate-200"
                    >
                        <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                                <Input id="name" name="name" type="text" required placeholder="John Doe" />
                            </div>
                            <div>
                                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                                <Input id="email" name="email" type="email" required placeholder="you@example.com" />
                            </div>
                            <div>
                                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">Phone Number (Optional)</label>
                                <Input id="phone" name="phone" type="tel" placeholder="+1 (555) 123-4567" />
                            </div>
                            <div>
                                <label htmlFor="service-type" className="block text-sm font-medium text-gray-700 mb-2">Type of Service</label>
                                <Select name="service-type" required>
                                    <SelectTrigger id="service-type">
                                        <SelectValue placeholder="Select a service" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="full-website">Full Website Build</SelectItem>
                                        <SelectItem value="landing-page">Landing Page</SelectItem>
                                        <SelectItem value="e-commerce-store">E-commerce Store</SelectItem>
                                        <SelectItem value="portfolio">Portfolio Site</SelectItem>
                                        <SelectItem value="other">Other</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="sm:col-span-2">
                                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">Project Description</label>
                                <Textarea id="description" name="description" required placeholder="Tell us about your vision, goals, and key features..." rows={6} />
                            </div>
                            <div>
                                <label htmlFor="timeframe" className="block text-sm font-medium text-gray-700 mb-2">Ideal Timeframe</label>
                                <Input id="timeframe" name="timeframe" type="text" placeholder="e.g., 2-4 weeks" />
                            </div>
                            <div>
                                <label htmlFor="budget" className="block text-sm font-medium text-gray-700 mb-2">Estimated Budget</label>
                                <Select name="budget">
                                    <SelectTrigger id="budget">
                                        <SelectValue placeholder="Select your budget range" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="<5k">$1,000 - $5,000</SelectItem>
                                        <SelectItem value="5k-10k">$5,000 - $10,000</SelectItem>
                                        <SelectItem value="10k-20k">$10,000 - $20,000</SelectItem>
                                        <SelectItem value=">20k">$20,000+</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="sm:col-span-2 flex justify-end">
                                <Button type="submit" size="lg" className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700">
                                    Send Request
                                    <Send className="ml-2 h-4 w-4" />
                                </Button>
                            </div>
                        </form>
                    </motion.div>
                </div>
            </div>
        </>
    );
};

export default CustomRequestPage;