import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/use-toast';
import { Wrench, Send } from 'lucide-react';

const MigrationPage = () => {

    const handleSubmit = (e) => {
        e.preventDefault();
        toast({
            title: "🛠️ Help Request Submitted",
            description: "We've received your request and will get in touch shortly to assist you.",
        });
        e.target.reset();
    };

    return (
        <>
            <Helmet>
                <title>Migration & Integration Help - CodeSnippets Pro</title>
                <meta name="description" content="Need help integrating a snippet into your project or migrating your site? Our team is here to help." />
            </Helmet>
            <div className="bg-white py-16 sm:py-24 px-4 sm:px-6 lg:px-8">
                <div className="max-w-2xl mx-auto">
                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6 }}
                        className="text-center"
                    >
                        <Wrench className="mx-auto h-16 w-16 text-blue-600" />
                        <h1 className="mt-4 text-4xl sm:text-5xl font-bold text-gray-900 tracking-tight">Need a Hand?</h1>
                        <p className="mt-4 text-xl text-gray-600">
                            Whether you need help installing a snippet, customizing it, or migrating your platform, our experts are here to help.
                        </p>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.2 }}
                        className="mt-16 bg-slate-50 p-8 sm:p-12 rounded-2xl shadow-lg border border-slate-200"
                    >
                        <form onSubmit={handleSubmit} className="space-y-8">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">Your Name</label>
                                <Input id="name" name="name" type="text" required placeholder="Alex Ray" />
                            </div>
                            <div>
                                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">Your Email</label>
                                <Input id="email" name="email" type="email" required placeholder="you@example.com" />
                            </div>
                            <div>
                                <label htmlFor="website" className="block text-sm font-medium text-gray-700 mb-2">Your Website URL (if applicable)</label>
                                <Input id="website" name="website" type="url" placeholder="https://yourwebsite.com" />
                            </div>
                            <div>
                                <label htmlFor="request-details" className="block text-sm font-medium text-gray-700 mb-2">How can we help?</label>
                                <Textarea id="request-details" name="request-details" required placeholder="Please describe the issue you're facing or the help you need. The more details, the better!" rows={6} />
                            </div>
                            <div className="flex justify-end">
                                <Button type="submit" size="lg" className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700">
                                    Get Help
                                    <Send className="ml-2 h-4 w-4" />
                                </Button>
                            </div>
                        </form>
                    </motion.div>
                </div>
            </div>
        </>
    );
};

export default MigrationPage;