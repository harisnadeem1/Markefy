import React from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { allProducts, categories } from '@/data/products';
import { reviews } from '@/data/products';
import CategoryIntro from '@/components/shop/CategoryIntro';
import ProductGrid from '@/components/shop/ProductGrid';
import CustomerReviews from '@/components/shop/CustomerReviews';

const CategoryPage = () => {
  const { category } = useParams();
  
  if (category === 'all') {
    return <Navigate to="/shop" replace />;
  }
  
  const productsToShow = allProducts.filter(p => p.category === category);
  const categoryTitle = categories[category] ? `${categories[category]} Snippets` : 'Snippets';

  if (!categories[category]) {
    return <Navigate to="/404" replace />;
  }

  return (
    <>
      <Helmet>
        <title>{categoryTitle} - CodeSnippets Pro</title>
        <meta name="description" content={`Explore our premium, pre-built ${categoryTitle}. Copy, paste, and customize within minutes.`} />
        <meta property="og:title" content={`${categoryTitle} - CodeSnippets Pro`} />
        <meta property="og:description" content={`Explore our premium, pre-built ${categoryTitle}. Copy, paste, and customize within minutes.`} />
      </Helmet>
      
      <CategoryIntro categoryName={categoryTitle} />
      
      <div className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {productsToShow.length > 0 ? (
            <ProductGrid products={productsToShow} />
          ) : (
            <div className="text-center py-16">
              <h2 className="text-2xl font-semibold text-gray-700">No snippets found in this category yet.</h2>
              <p className="text-gray-500 mt-2">Check back soon or browse our other categories!</p>
            </div>
          )}
        </div>
      </div>

      <CustomerReviews reviews={reviews} />
    </>
  );
};

export default CategoryPage;