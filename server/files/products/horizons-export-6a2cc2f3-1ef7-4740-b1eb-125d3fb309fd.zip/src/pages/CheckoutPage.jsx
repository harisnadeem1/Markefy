import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '@/hooks/useCart';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { toast } from '@/components/ui/use-toast';
import { Code, ShoppingCart, Lock, ArrowLeft, ChevronDown, ChevronUp } from 'lucide-react';

const CheckoutPage = () => {
    const { cart, getCartTotal, clearCart } = useCart();
    const navigate = useNavigate();
    const total = getCartTotal();

    const [formData, setFormData] = useState({
        fullName: '',
        email: '',
        phone: '',
    });

    React.useEffect(() => {
        if (cart.length === 0) {
            navigate('/cart');
        }
    }, [cart, navigate]);

    if (cart.length === 0) {
        return null;
    }

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handlePlaceOrder = (e) => {
        e.preventDefault();
        const orderDetails = {
            items: cart,
            total: total,
            customer: formData
        };
        // In a real app, you would process payment here.
        // On success, navigate to confirmation page.
        clearCart();
        navigate('/order-confirmation', { state: { order: orderDetails } });
        toast({
            title: "🎉 Order Confirmed!",
            description: "Thank you for your purchase. Your download links are ready.",
        });
    };

    const OrderSummary = () => (
        <div className="space-y-4">
            {cart.map(item => (
                <div key={item.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="relative w-16 h-16">
                            <img  alt={item.title} class="w-full h-full object-cover rounded-lg border border-gray-200" src="https://images.unsplash.com/photo-1687006067259-6de13ca3875e" />
                            <span className="absolute -top-2 -right-2 flex h-6 w-6 items-center justify-center rounded-full bg-gray-500 text-white text-xs font-semibold">1</span>
                        </div>
                        <div>
                            <p className="font-semibold text-gray-800">{item.title}</p>
                            <p className="text-sm text-gray-500">{item.category}</p>
                        </div>
                    </div>
                    <p className="font-medium text-gray-800">{item.price}</p>
                </div>
            ))}
            <div className="border-t border-gray-200 pt-4 space-y-2">
                <div className="flex justify-between text-gray-600">
                    <span>Subtotal</span>
                    <span className="font-medium">${total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                    <span>Taxes</span>
                    <span className="font-medium">$0.00</span>
                </div>
            </div>
            <div className="border-t border-gray-200 pt-4 flex justify-between font-bold text-xl text-gray-900">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
            </div>
        </div>
    );

    return (
        <>
            <Helmet>
                <title>Checkout - CodeSnippets Pro</title>
                <meta name="description" content="Complete your purchase securely." />
            </Helmet>
            <div className="min-h-screen font-sans bg-white text-gray-800 lg:grid lg:grid-cols-2">
                {/* Left Side: Form */}
                <main className="lg:col-span-1 lg:py-12 lg:pr-12 lg:border-r border-gray-200">
                    <div className="max-w-lg mx-auto px-4 lg:px-8 py-8 lg:py-0">
                        <Link to="/" className="flex items-center space-x-2 mb-8">
                            <Code className="h-8 w-8 text-blue-600" />
                            <span className="text-2xl font-bold text-gray-800">CodeSnippets Pro</span>
                        </Link>
                        
                        {/* Mobile Order Summary Accordion */}
                        <div className="lg:hidden mb-8">
                           <Accordion type="single" collapsible className="w-full border-t border-b border-gray-200">
                                <AccordionItem value="item-1">
                                    <AccordionTrigger className="hover:no-underline">
                                        <div className="flex items-center gap-2">
                                            <ShoppingCart className="h-5 w-5 text-blue-600" />
                                            <span className="text-blue-600">Show order summary</span>
                                            <ChevronDown className="h-5 w-5 text-blue-600 transition-transform duration-200" />
                                        </div>
                                        <p className="text-lg font-semibold">${total.toFixed(2)}</p>
                                    </AccordionTrigger>
                                    <AccordionContent className="pt-4 bg-gray-50 p-4 rounded-b-lg">
                                        <OrderSummary />
                                    </AccordionContent>
                                </AccordionItem>
                            </Accordion>
                        </div>

                        <form onSubmit={handlePlaceOrder} className="space-y-6">
                            <div>
                                <h2 className="text-xl font-semibold mb-4">Contact</h2>
                                <Input id="email" name="email" type="email" value={formData.email} onChange={handleInputChange} required placeholder="Email" />
                            </div>

                            <div>
                                <h2 className="text-xl font-semibold mb-4">Delivery</h2>
                                <div className="space-y-4">
                                  <Input id="fullName" name="fullName" type="text" value={formData.fullName} onChange={handleInputChange} required placeholder="Full name" />
                                  <Input id="phone" name="phone" type="tel" value={formData.phone} onChange={handleInputChange} placeholder="Phone (optional)" />
                                </div>
                            </div>
                            
                            <div>
                                <h2 className="text-xl font-semibold mb-4">Payment</h2>
                                <p className="text-gray-500 mb-4">All transactions are secure and encrypted.</p>
                                <div className="border rounded-lg p-4 space-y-4">
                                    <Input id="card-number" name="card-number" type="text" required placeholder="Card number" />
                                    <div className="flex gap-4">
                                        <Input type="text" required placeholder="MM / YY" />
                                        <Input type="text" required placeholder="CVV" />
                                    </div>
                                </div>
                            </div>

                            <div className="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-between gap-4 pt-4">
                                <Link to="/cart" className="flex items-center text-blue-600 hover:text-blue-800">
                                    <ArrowLeft className="h-4 w-4 mr-1" />
                                    Return to cart
                                </Link>
                                <Button type="submit" size="lg" className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 h-14 text-base">
                                    Pay now
                                </Button>
                            </div>
                        </form>

                        <div className="mt-8 text-center text-xs text-gray-500">
                            By continuing, you agree to the <a href="#" className="underline">Terms of Service</a> and <a href="#" className="underline">Privacy Policy</a>.
                        </div>

                    </div>
                </main>

                {/* Right Side: Order Summary */}
                <aside className="hidden lg:block lg:col-span-1 bg-gray-50 py-12 lg:pl-12">
                     <div className="max-w-lg mx-auto px-4 lg:px-8">
                         <h2 className="text-xl font-semibold mb-6">Order summary</h2>
                         <OrderSummary />
                     </div>
                </aside>
            </div>
        </>
    );
};

export default CheckoutPage;