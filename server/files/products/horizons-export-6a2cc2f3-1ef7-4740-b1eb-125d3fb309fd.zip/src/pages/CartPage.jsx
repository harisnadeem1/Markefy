import React from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useCart } from '@/hooks/useCart';
import { Button } from '@/components/ui/button';
import { Trash2, ShoppingCart, ArrowRight } from 'lucide-react';

const CartPage = () => {
  const { cart, removeFromCart, getCartTotal } = useCart();
  const navigate = useNavigate();

  const handleCheckout = () => {
    navigate('/checkout');
  };

  const total = getCartTotal();

  return (
    <>
      <Helmet>
        <title>Your Shopping Cart - CodeSnippets Pro</title>
        <meta name="description" content="Review and manage items in your shopping cart before proceeding to checkout." />
      </Helmet>
      <div className="bg-slate-50 py-12 sm:py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900">Your Cart</h1>
            <p className="mt-4 text-lg text-gray-600">Review your items and proceed to checkout.</p>
          </motion.div>

          {cart.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-16 px-6 bg-white rounded-lg shadow-md"
            >
              <ShoppingCart className="mx-auto h-16 w-16 text-gray-400" />
              <h2 className="mt-6 text-2xl font-semibold text-gray-800">Your cart is empty</h2>
              <p className="mt-2 text-gray-500">Looks like you haven't added any snippets yet.</p>
              <Button asChild size="lg" className="mt-8 bg-blue-600 hover:bg-blue-700">
                <Link to="/shop">
                  Shop Now <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </motion.div>
          ) : (
            <div className="grid lg:grid-cols-3 gap-8 lg:gap-12">
              <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow-md">
                <h2 className="text-2xl font-semibold text-gray-800 mb-6">Cart Items ({cart.length})</h2>
                <div className="space-y-6">
                  <AnimatePresence>
                    {cart.map(item => (
                      <motion.div
                        key={item.id}
                        layout
                        initial={{ opacity: 0, x: -50 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 50, transition: { duration: 0.3 } }}
                        className="flex flex-col sm:flex-row items-center gap-6 border-b pb-6 last:border-b-0"
                      >
                        <img  class="w-24 h-24 sm:w-32 sm:h-32 object-cover rounded-md flex-shrink-0" alt={item.title} src="https://images.unsplash.com/photo-1687006067259-6de13ca3875e" />
                        <div className="flex-grow text-center sm:text-left">
                          <Link to={`/product/${item.id}`} className="font-semibold text-lg text-gray-800 hover:text-blue-600">{item.title}</Link>
                          <p className="text-gray-500 text-sm mt-1">{item.category}</p>
                        </div>
                        <p className="font-semibold text-xl w-24 text-center sm:text-right">{item.price}</p>
                        <Button variant="ghost" size="icon" onClick={() => removeFromCart(item.id)} className="text-gray-400 hover:text-red-500">
                          <Trash2 className="h-5 w-5" />
                        </Button>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </div>

              <div className="lg:col-span-1">
                <div className="bg-white p-6 rounded-lg shadow-md sticky top-24">
                  <h2 className="text-2xl font-semibold text-gray-800 border-b pb-4 mb-4">Order Summary</h2>
                  <div className="space-y-4">
                    <div className="flex justify-between text-gray-600">
                      <span>Subtotal</span>
                      <span>${total.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-gray-600">
                      <span>Taxes</span>
                      <span>Calculated at checkout</span>
                    </div>
                    <div className="border-t pt-4 mt-4 flex justify-between font-bold text-xl text-gray-900">
                      <span>Total</span>
                      <span>${total.toFixed(2)}</span>
                    </div>
                  </div>
                  <Button onClick={handleCheckout} size="lg" className="w-full mt-6 bg-blue-600 hover:bg-blue-700">
                    Proceed to Checkout
                  </Button>
                  <Button asChild variant="link" className="w-full mt-2 text-blue-600">
                    <Link to="/shop">Continue Shopping</Link>
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default CartPage;