import React from 'react';
import { useParams, Link, Navigate, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { allProducts, demoThumbnails } from '@/data/products';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Star, CheckCircle2, ChevronRight, ExternalLink, ShoppingCart } from 'lucide-react';
import ProductGallery from '@/components/shop/ProductGallery';
import { useCart } from '@/hooks/useCart';

const ProductPage = () => {
  const { productId } = useParams();
  const { addToCart, cart } = useCart();
  const navigate = useNavigate();
  const product = allProducts.find(p => p.id === parseInt(productId));

  if (!product) {
    return <Navigate to="/404" replace />;
  }

  const isInCart = cart.some(item => item.id === product.id);
  
  const handleAddToCart = () => {
    addToCart(product);
  };

  const handleBuyNow = () => {
    addToCart(product);
    navigate('/checkout');
  };

  const handleActionClick = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const breadcrumbs = product.tags ? product.tags.join(' | ') : 'Code Snippet';

  return (
    <>
      <Helmet>
        <title>{product.title} - CodeSnippets Pro</title>
        <meta name="description" content={product.description} />
        <meta property="og:title" content={`${product.title} - CodeSnippets Pro`} />
        <meta property="og:description" content={product.description} />
      </Helmet>

      <div className="bg-slate-50 font-sans">
        <div className="container mx-auto px-4 py-12">
          <div className="grid lg:grid-cols-3 gap-8 xl:gap-12">
            
            <div className="lg:col-span-2">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="bg-white rounded-lg shadow-sm border border-gray-200 p-2"
              >
                <div className="relative aspect-[16/10] overflow-hidden rounded-md">
                   <img  class="w-full h-full object-cover" alt="Product demo" src="https://images.unsplash.com/photo-1635870224272-77fcf1f3dd1f" />
                   <div className="absolute top-4 right-4 flex flex-col gap-2">
                      {product.tags.includes('NEW!') && <div className="bg-red-600 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg">NEW!</div>}
                      {product.tags.includes('With Video') && <div className="bg-blue-600 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg">WITH VIDEO!</div>}
                  </div>
                </div>

                <div className="bg-gray-800 text-white flex items-center justify-between p-3 rounded-b-md mt-2">
                    <button onClick={handleActionClick} className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wider hover:text-blue-400 transition-colors">
                        Check out the demo <ExternalLink className="w-4 h-4"/>
                    </button>
                    <div className="flex items-center gap-2">
                        <button className="p-1 hover:bg-gray-700 rounded-full" aria-label="Previous Demo">
                            <ChevronRight className="w-5 h-5 rotate-180" />
                        </button>
                        <button className="p-1 hover:bg-gray-700 rounded-full" aria-label="Next Demo">
                            <ChevronRight className="w-5 h-5" />
                        </button>
                    </div>
                </div>
              </motion.div>
              <ProductGallery thumbnails={demoThumbnails} />
            </div>

            <aside className="lg:col-span-1">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="space-y-6"
              >
                <div>
                  <p className="text-blue-600 text-xs font-semibold uppercase tracking-wider mb-2">{breadcrumbs}</p>
                  <h1 className="text-3xl lg:text-4xl font-bold text-gray-900">{product.title}</h1>
                  <div className="flex items-center mt-2">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`h-5 w-5 ${i < product.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} />
                    ))}
                  </div>
                </div>

                <div>
                  <p className="text-4xl font-bold text-gray-900">{product.price}</p>
                  <p className="text-sm text-gray-500 mt-1">Pay just once. No subscription needed!</p>
                </div>

                <p className="text-base text-gray-600">{product.description}</p>
                
                <div className="space-y-3">
                  <Button onClick={handleAddToCart} size="lg" className="w-full text-base bg-blue-600 hover:bg-blue-700" disabled={isInCart}>
                    <ShoppingCart className="mr-2 h-5 w-5" />
                    {isInCart ? 'Already in Cart' : 'Add to Cart'}
                  </Button>
                  <Button onClick={handleBuyNow} size="lg" className="w-full text-base bg-purple-600 hover:bg-purple-700">Buy Now</Button>
                </div>

                <div>
                  <h3 className="font-semibold text-lg mb-3 text-gray-900">Features include:</h3>
                  <ul className="space-y-2.5 text-sm text-gray-600">
                    {product.features && product.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle2 className="w-4 h-4 mr-3 mt-0.5 text-green-500 shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            </aside>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProductPage;