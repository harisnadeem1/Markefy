import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { 
  Download, 
  Copy, 
  Palette, 
  Star, 
  ArrowRight, 
  CheckCircle,
  Zap,
  Shield,
  Clock
} from 'lucide-react';
import { allProducts } from '@/data/products';
import ProductGrid from '@/components/shop/ProductGrid';

const HomePage = () => {
  const handleShopNow = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const handleFreeSnippet = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const handleSubscribe = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };
  
  const featuredProducts = allProducts.slice(0, 4);

  return (
    <>
      <Helmet>
        <title>CodeSnippets Pro - Premium Code Templates for Developers</title>
        <meta name="description" content="Explore our super-flexible code snippet templates that you can easily add to your projects. Redesign your project within minutes with professional components." />
        <meta property="og:title" content="CodeSnippets Pro - Premium Code Templates for Developers" />
        <meta property="og:description" content="Explore our super-flexible code snippet templates that you can easily add to your projects. Redesign your project within minutes with professional components." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-8"
            >
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                <span className="gradient-text">Redesign your project</span>
                <br />
                <span className="text-gray-900">within minutes</span>
              </h1>
              <p className="text-xl text-gray-600 max-w-lg">
                Explore our super-flexible code snippet templates that you can easily add to your projects.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-4">
                  <Link to="/shop">
                    Shop Now
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button 
                  onClick={handleFreeSnippet}
                  variant="outline" 
                  size="lg" 
                  className="text-lg px-8 py-4"
                >
                  Try Free Snippet
                </Button>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="glass-card rounded-2xl p-8">
                <img  alt="Developer coding on laptop with modern setup" class="w-full h-80 object-cover rounded-lg" src="https://images.unsplash.com/photo-1452457750107-cd084dce177d" />
                <div className="absolute -bottom-4 -right-4 bg-green-500 text-white px-4 py-2 rounded-full font-semibold shadow-lg">
                  <CheckCircle className="inline h-4 w-4 mr-1" />
                  Ready to Use
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Install within minutes</h2>
            <p className="text-xl text-gray-600">Customize your project with a quick, intuitive 3-step setup</p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: "1",
                icon: Download,
                title: "Get the code",
                description: "After your purchase, you'll get a link.",
                color: "bg-blue-500"
              },
              {
                step: "2",
                icon: Copy,
                title: "Copy & paste the code",
                description: "Simple instructions included.",
                color: "bg-purple-500"
              },
              {
                step: "3",
                icon: Palette,
                title: "Add & style your content",
                description: "Easily customize to fit your needs.",
                color: "bg-green-500"
              }
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="text-center group"
              >
                <div className={`${item.color} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <item.icon className="h-8 w-8 text-white" />
                </div>
                <div className="bg-gray-900 text-white w-8 h-8 rounded-full flex items-center justify-center mx-auto mb-4 text-sm font-bold">
                  {item.step}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Featured Snippets for Your Projects</h2>
            <p className="text-xl text-gray-600">Professional components ready to integrate</p>
          </motion.div>
          <ProductGrid products={featuredProducts} />
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Happy customers who saved time and money</h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "John D.",
                review: "The snippet was super easy to install and saved me hours of work. Perfect!",
                avatar: "Professional male developer with glasses"
              },
              {
                name: "Sarah M.",
                review: "Amazing quality and documentation. Will definitely buy more snippets!",
                avatar: "Female developer with curly hair"
              },
              {
                name: "Mike R.",
                review: "Clean code, great design, and excellent support. Highly recommended!",
                avatar: "Young male developer with beard"
              }
            ].map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="glass-card rounded-xl p-6"
              >
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 italic">"{testimonial.review}"</p>
                <div className="flex items-center">
                  <img  alt={testimonial.avatar} class="w-10 h-10 rounded-full mr-3" src="https://images.unsplash.com/photo-1694157263770-1a844cb0f6e0" />
                  <span className="font-semibold text-gray-900">– {testimonial.name}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Free Snippet Promo */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <h2 className="text-4xl font-bold text-white mb-4">Try a Free Snippet</h2>
            <p className="text-xl text-blue-100 mb-8">
              Get a sense of using our snippets and how flexible they can be.
            </p>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 mb-8">
              <div className="code-preview bg-gray-900/80">
                {`// Free Button Component
const Button = ({ children, variant = "primary" }) => {
  return (
    <button className={\`btn btn-\${variant}\`}>
      {children}
    </button>
  );
};`}
              </div>
            </div>

            <Button 
              onClick={handleFreeSnippet}
              size="lg" 
              className="bg-white text-blue-600 hover:bg-gray-100 text-lg px-8 py-4"
            >
              <Download className="mr-2 h-5 w-5" />
              Try the Free Snippet
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <h2 className="text-4xl font-bold text-white mb-4">
              Sign up to receive 15% off your first order!
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Join thousands of developers getting premium snippets and exclusive deals.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 rounded-lg border border-gray-600 bg-gray-800 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Button 
                onClick={handleSubscribe}
                className="bg-blue-600 hover:bg-blue-700 px-8 py-3"
              >
                Subscribe
              </Button>
            </div>
            
            <div className="flex items-center justify-center space-x-8 text-gray-400 text-sm">
              <div className="flex items-center">
                <Shield className="h-4 w-4 mr-1" />
                Secure & Private
              </div>
              <div className="flex items-center">
                <Zap className="h-4 w-4 mr-1" />
                Instant Access
              </div>
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                Cancel Anytime
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </>
  );
};

export default HomePage;