import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { CheckCircle, Layers, FastForward } from 'lucide-react';

const WhatAreSnippetsPage = () => {
    return (
        <>
            <Helmet>
                <title>What Are Code Snippets? - CodeSnippets Pro</title>
                <meta name="description" content="Understand what code snippets are, how they work, and how they can dramatically speed up your web development process." />
            </Helmet>
            <div className="bg-white py-16 sm:py-24 px-4 sm:px-6 lg:px-8">
                <div className="max-w-7xl mx-auto">
                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6 }}
                        className="text-center"
                    >
                        <p className="text-base font-semibold text-blue-600 tracking-wide uppercase">The Basics</p>
                        <h1 className="mt-2 text-4xl sm:text-5xl font-bold text-gray-900 tracking-tight">What Exactly Are Code Snippets?</h1>
                        <p className="mt-6 max-w-3xl mx-auto text-xl text-gray-600">
                            Think of them as pre-built, production-ready Lego blocks for your website. Instead of building common components from scratch, you just copy and paste ours.
                        </p>
                    </motion.div>

                    <div className="mt-20">
                        <div className="grid lg:grid-cols-2 gap-16 items-center">
                            <motion.div
                                initial={{ opacity: 0, x: -50 }}
                                whileInView={{ opacity: 1, x: 0 }}
                                transition={{ duration: 0.7, delay: 0.2 }}
                                viewport={{ once: true }}
                            >
                                <img  class="w-full h-auto object-cover rounded-xl shadow-2xl" alt="A visual representation of code blocks being assembled into a web page" src="https://images.unsplash.com/photo-1518773553398-650c184e0bb3" />
                            </motion.div>
                            <motion.div
                                initial={{ opacity: 0, x: 50 }}
                                whileInView={{ opacity: 1, x: 0 }}
                                transition={{ duration: 0.7, delay: 0.4 }}
                                viewport={{ once: true }}
                                className="space-y-8"
                            >
                                <h2 className="text-3xl font-bold text-gray-900">How They Work</h2>
                                <p className="text-lg text-gray-600">
                                    Each snippet is a self-contained piece of HTML, CSS, and sometimes JavaScript, built with best practices in mind. They are designed to be easily integrated into any existing project, regardless of the framework you're using.
                                </p>
                                <ul className="space-y-4">
                                    <li className="flex items-start">
                                        <CheckCircle className="h-6 w-6 text-green-500 mr-4 mt-1 flex-shrink-0" />
                                        <span><span className="font-semibold">Copy & Paste:</span> Simply copy the code provided after your purchase.</span>
                                    </li>
                                    <li className="flex items-start">
                                        <CheckCircle className="h-6 w-6 text-green-500 mr-4 mt-1 flex-shrink-0" />
                                        <span><span className="font-semibold">Customize:</span> Easily change text, images, and colors to match your brand. Our code is clean and easy to understand.</span>
                                    </li>
                                    <li className="flex items-start">
                                        <CheckCircle className="h-6 w-6 text-green-500 mr-4 mt-1 flex-shrink-0" />
                                        <span><span className="font-semibold">Go Live:</span> Save hours, or even days, of development time on every project.</span>
                                    </li>
                                </ul>
                            </motion.div>
                        </div>
                    </div>

                    <div className="mt-24">
                        <div className="text-center mb-16">
                            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">The Benefits of Using Snippets</h2>
                            <p className="mt-4 text-xl text-gray-600">More than just code, it's a better way to build.</p>
                        </div>
                        <div className="grid md:grid-cols-3 gap-10">
                            <div className="text-center">
                                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-blue-100 mb-6">
                                    <FastForward className="h-8 w-8 text-blue-600" />
                                </div>
                                <h3 className="text-xl font-semibold text-gray-900">Accelerate Development</h3>
                                <p className="mt-2 text-gray-600">Stop wasting time on repetitive tasks. Launch your projects and features faster than ever before.</p>
                            </div>
                            <div className="text-center">
                                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-purple-100 mb-6">
                                    <Layers className="h-8 w-8 text-purple-600" />
                                </div>
                                <h3 className="text-xl font-semibold text-gray-900">Ensure Consistency</h3>
                                <p className="mt-2 text-gray-600">Maintain a consistent design language and user experience across your entire application with ease.</p>
                            </div>
                            <div className="text-center">
                                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-green-100 mb-6">
                                    <CheckCircle className="h-8 w-8 text-green-600" />
                                </div>
                                <h3 className="text-xl font-semibold text-gray-900">Professional Quality</h3>
                                <p className="mt-2 text-gray-600">Leverage components that are already optimized for responsiveness, accessibility, and performance.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default WhatAreSnippetsPage;