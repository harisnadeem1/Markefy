
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { cn } from '@/lib/utils';

const faqData = {
  general: [
    {
      question: "Do I need coding experience?",
      answer: "Our snippets are designed to be beginner-friendly. Basic knowledge of HTML/CSS is helpful, but we provide clear instructions to get you up and running in minutes."
    },
    {
      question: "Can I use this on any website theme?",
      answer: "Yes! Our components are built to be theme-agnostic. They are self-contained and will adopt your existing font styles while maintaining their core design."
    },
    {
      question: "How do I install the snippet?",
      answer: "Installation is simple: 1. You'll receive the code after purchase. 2. Copy the code. 3. Paste it into your website's HTML where you want it to appear. Detailed steps are included."
    },
  ],
  purchasing: [
    {
      question: "What payment methods do you accept?",
      answer: "We accept all major credit cards (Visa, Mastercard, American Express) as well as PayPal for secure and easy transactions."
    },
    {
      question: "Is this a one-time payment?",
      answer: "Absolutely. All our snippets are a one-time purchase. You get lifetime access with no recurring fees or subscriptions."
    },
    {
      question: "What is your refund policy?",
      answer: "Due to the digital nature of our products, we generally do not offer refunds. However, if you encounter a technical issue we cannot resolve, we are happy to discuss a solution."
    }
  ],
  help: [
    {
      question: "What if I need help with a snippet?",
      answer: "We offer dedicated support for all our premium snippets. If you run into any issues, just contact our help desk, and we'll be happy to assist you."
    },
    {
      question: "Do you offer customization services?",
      answer: "Yes, we do! If you need a snippet tailored to your specific needs or a completely custom component, please visit our 'Custom Snippets' request page to get a quote."
    },
    {
      question: "Where can I find the documentation?",
      answer: "Each snippet comes with its own clear, concise documentation. You will receive a link to the documentation along with your download after purchase."
    }
  ]
};

const FaqPage = () => {
  const [activeTab, setActiveTab] = useState('general');

  return (
    <>
      <Helmet>
        <title>FAQ - CodeSnippets Pro</title>
        <meta name="description" content="Find answers to frequently asked questions about our code snippets, purchasing process, and support." />
      </Helmet>
      <div className="bg-white py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900">Frequently Asked Questions</h1>
            <p className="mt-4 text-lg text-gray-600">Have questions? We have answers.</p>
          </div>

          <div className="grid lg:grid-cols-4 gap-8">
            <aside className="lg:col-span-1">
              <nav className="space-y-1 sticky top-24">
                <button
                  onClick={() => setActiveTab('general')}
                  className={cn(
                    'w-full text-left px-4 py-2.5 rounded-md text-sm font-medium transition-colors',
                    activeTab === 'general' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:bg-gray-100'
                  )}
                >
                  General
                </button>
                <button
                  onClick={() => setActiveTab('purchasing')}
                  className={cn(
                    'w-full text-left px-4 py-2.5 rounded-md text-sm font-medium transition-colors',
                    activeTab === 'purchasing' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:bg-gray-100'
                  )}
                >
                  Purchasing a Section
                </button>
                <button
                  onClick={() => setActiveTab('help')}
                  className={cn(
                    'w-full text-left px-4 py-2.5 rounded-md text-sm font-medium transition-colors',
                    activeTab === 'help' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:bg-gray-100'
                  )}
                >
                  How We Can Help
                </button>
              </nav>
            </aside>

            <main className="lg:col-span-3">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Accordion type="single" collapsible className="w-full">
                  {faqData[activeTab].map((item, index) => (
                    <AccordionItem key={index} value={`item-${index}`}>
                      <AccordionTrigger className="text-lg text-left hover:no-underline">
                        {item.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-base text-gray-600 leading-relaxed">
                        {item.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </motion.div>
            </main>
          </div>
        </div>
      </div>
    </>
  );
};

export default FaqPage;
