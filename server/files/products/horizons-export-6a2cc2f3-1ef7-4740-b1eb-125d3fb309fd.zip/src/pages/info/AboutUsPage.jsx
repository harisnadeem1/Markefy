import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Users, Target, Rocket } from 'lucide-react';

const AboutUsPage = () => {
    const teamMembers = [
        { name: 'Alex Johnson', role: 'Founder & Lead Developer', avatar: 'Focused male software engineer coding' },
        { name: 'Maria Garcia', role: 'UI/UX Designer', avatar: 'Creative female designer sketching on a tablet' },
        { name: 'Sam Chen', role: 'Marketing & Support', avatar: 'Friendly male support agent with a headset' },
    ];

    return (
        <>
            <Helmet>
                <title>About Us - CodeSnippets Pro</title>
                <meta name="description" content="Learn about the team and mission behind CodeSnippets Pro, dedicated to providing high-quality code components for developers." />
            </Helmet>
            <div className="bg-white">
                {/* Hero Section */}
                <div className="relative bg-gray-900 py-24 sm:py-32">
                    <img  class="absolute inset-0 h-full w-full object-cover" alt="Abstract blue and purple digital art" src="https://images.unsplash.com/photo-1700941019917-731dc64ce685" />
                    <div className="absolute inset-0 bg-gray-900/60"></div>
                    <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                        <motion.h1
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.6 }}
                            className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white tracking-tight"
                        >
                            We're Powering the Next Wave of Digital Creation
                        </motion.h1>
                        <motion.p
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.6, delay: 0.2 }}
                            className="mt-6 text-lg sm:text-xl text-gray-300 max-w-3xl mx-auto"
                        >
                            At CodeSnippets Pro, we believe that great projects are built one component at a time. Our mission is to provide developers with beautiful, reliable, and easy-to-use code snippets to accelerate their workflow.
                        </motion.p>
                    </div>
                </div>

                {/* Mission Section */}
                <div className="py-16 sm:py-24 px-4 sm:px-6 lg:px-8">
                    <div className="max-w-7xl mx-auto">
                        <div className="grid lg:grid-cols-3 gap-12 text-center">
                            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }} viewport={{ once: true }}>
                                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-blue-100">
                                    <Users className="h-8 w-8 text-blue-600" />
                                </div>
                                <h3 className="mt-6 text-2xl font-semibold text-gray-900">Who We Are</h3>
                                <p className="mt-4 text-gray-600">We are a passionate team of developers and designers who love building for the web. We got tired of reinventing the wheel on every project, so we decided to create a library of top-tier components for everyone.</p>
                            </motion.div>
                            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }} viewport={{ once: true }}>
                                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-purple-100">
                                    <Target className="h-8 w-8 text-purple-600" />
                                </div>
                                <h3 className="mt-6 text-2xl font-semibold text-gray-900">Our Mission</h3>
                                <p className="mt-4 text-gray-600">Our goal is to save you time and effort. By providing production-ready code snippets, we empower you to focus on what truly matters: building unique features and delivering exceptional user experiences.</p>
                            </motion.div>
                            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} viewport={{ once: true }}>
                                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
                                    <Rocket className="h-8 w-8 text-green-600" />
                                </div>
                                <h3 className="mt-6 text-2xl font-semibold text-gray-900">Our Vision</h3>
                                <p className="mt-4 text-gray-600">We envision a world where developers can assemble stunning, high-performance websites faster than ever before. We're constantly expanding our library to be the ultimate toolkit for modern web development.</p>
                            </motion.div>
                        </div>
                    </div>
                </div>

                {/* Team Section */}
                <div className="bg-slate-50 py-16 sm:py-24">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div className="text-center">
                            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">Meet the Team</h2>
                            <p className="mt-4 text-lg text-gray-600">The minds behind the code.</p>
                        </div>
                        <div className="mt-12 grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-3">
                            {teamMembers.map((member, index) => (
                                <motion.div key={member.name} initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5, delay: index * 0.1 }} viewport={{ once: true }} className="text-center">
                                    <img  class="mx-auto h-40 w-40 rounded-full object-cover" alt={member.name} src="https://images.unsplash.com/photo-1611762342062-86e06a30eb41" />
                                    <h3 className="mt-6 text-xl font-semibold text-gray-900">{member.name}</h3>
                                    <p className="text-blue-600">{member.role}</p>
                                </motion.div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default AboutUsPage;