import React from 'react';
import { Helmet } from 'react-helmet';
import { useLocation, Navigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { CheckCircle, Download, Code } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const OrderConfirmationPage = () => {
    const location = useLocation();
    const order = location.state?.order;

    if (!order) {
        return <Navigate to="/" replace />;
    }

    const handleDownload = (itemTitle) => {
        toast({
            title: `📥 Downloading ${itemTitle}`,
            description: "Your file download has started.",
        });
        // In a real app, this would trigger a file download.
    };

    return (
        <>
            <Helmet>
                <title>Order Confirmed - CodeSnippets Pro</title>
                <meta name="description" content="Your order has been successfully placed. Access your digital products here." />
            </Helmet>
            <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
                <div className="max-w-2xl w-full">
                    <div className="text-center mb-8">
                        <Link to="/" className="inline-flex items-center space-x-2">
                           <Code className="h-8 w-8 text-blue-600" />
                            <span className="text-2xl font-bold text-gray-800">CodeSnippets Pro</span>
                        </Link>
                    </div>

                    <div className="bg-white rounded-xl shadow-lg p-8 md:p-12 border border-gray-200">
                        <div className="text-center">
                            <CheckCircle className="mx-auto h-16 w-16 text-green-500" />
                            <h1 className="mt-4 text-3xl font-bold text-gray-900">Thank you for your order!</h1>
                            <p className="mt-2 text-gray-600">A confirmation email has been sent to <span className="font-semibold text-gray-800">{order.customer.email}</span>.</p>
                        </div>

                        <div className="mt-8 border-t border-gray-200 pt-8">
                            <h2 className="text-lg font-semibold text-gray-900 mb-4">Your Downloads</h2>
                            <div className="space-y-4">
                                {order.items.map(item => (
                                    <div key={item.id} className="flex flex-col sm:flex-row items-center justify-between p-4 bg-gray-50 rounded-lg border">
                                        <div className="flex items-center gap-4 mb-4 sm:mb-0">
                                            <img  alt={item.title} class="w-16 h-16 object-cover rounded-md" src="https://images.unsplash.com/photo-1687006067259-6de13ca3875e" />
                                            <div>
                                                <p className="font-semibold text-gray-800">{item.title}</p>
                                                <p className="text-sm text-gray-500">{item.price}</p>
                                            </div>
                                        </div>
                                        <Button onClick={() => handleDownload(item.title)}>
                                            <Download className="mr-2 h-4 w-4" />
                                            Download
                                        </Button>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="mt-8 text-center">
                            <Button asChild variant="link">
                                <Link to="/shop">Continue Shopping</Link>
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default OrderConfirmationPage;