import React from 'react';
import { Helmet } from 'react-helmet';
import { FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';

const AdminSalesPage = () => {
    // Mock data
    const sales = [
        { id: 'ORD001', customer: 'John Doe', date: '2025-08-21', total: '$29.00', status: 'Completed' },
        { id: 'ORD002', customer: 'Jane Smith', date: '2025-08-21', total: '$44.00', status: 'Completed' },
        { id: 'ORD003', customer: 'Mike Johnson', date: '2025-08-20', total: '$19.00', status: 'Completed' },
        { id: 'ORD004', customer: 'Sarah Brown', date: '2025-08-20', total: '$30.00', status: 'Completed' },
        { id: 'ORD005', customer: 'Chris Lee', date: '2025-08-19', total: '$18.00', status: 'Completed' },
    ];

    return (
        <>
            <Helmet><title>Sales Overview</title></Helmet>
            <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-8">Sales</h1>
                 <div className="bg-white rounded-lg shadow border border-gray-200">
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                <tr>
                                    <th scope="col" className="px-6 py-3">Order ID</th>
                                    <th scope="col" className="px-6 py-3">Customer</th>
                                    <th scope="col" className="px-6 py-3">Date</th>
                                    <th scope="col" className="px-6 py-3">Total</th>
                                    <th scope="col" className="px-6 py-3">Status</th>
                                    <th scope="col" className="px-6 py-3 text-right">Invoice</th>
                                </tr>
                            </thead>
                            <tbody>
                                {sales.map(sale => (
                                    <tr key={sale.id} className="bg-white border-b hover:bg-gray-50">
                                        <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">{sale.id}</th>
                                        <td className="px-6 py-4">{sale.customer}</td>
                                        <td className="px-6 py-4">{sale.date}</td>
                                        <td className="px-6 py-4">{sale.total}</td>
                                        <td className="px-6 py-4">
                                            <span className="px-2 py-1 text-xs font-medium text-green-800 bg-green-100 rounded-full">{sale.status}</span>
                                        </td>
                                        <td className="px-6 py-4 text-right">
                                            <Button variant="ghost" size="icon">
                                                <FileText className="h-4 w-4" />
                                            </Button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    );
};

export default AdminSalesPage;