
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { allProducts, categories as categoryData } from '@/data/products';
import { PlusCircle, Edit, Trash2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";

const AdminProductsPage = () => {
    const [products, setProducts] = useState(allProducts);

    const handleAddProduct = (e) => {
        e.preventDefault();
        toast({ title: "Product added!", description: "The new product has been saved." });
    };

    return (
        <>
            <Helmet><title>Manage Products</title></Helmet>
            <div>
                <div className="flex justify-between items-center mb-8">
                    <h1 className="text-3xl font-bold text-gray-900">Products</h1>
                    <Dialog>
                        <DialogTrigger asChild>
                            <Button><PlusCircle className="mr-2 h-4 w-4" /> Add Product</Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[625px]">
                            <DialogHeader>
                                <DialogTitle>Add New Product</DialogTitle>
                                <DialogDescription>Fill in the details for the new product.</DialogDescription>
                            </DialogHeader>
                            <form onSubmit={handleAddProduct} className="grid gap-4 py-4">
                                <Input name="name" placeholder="Product Name" required />
                                <Textarea name="description" placeholder="Short Description" required />
                                <Input name="price" type="text" placeholder="Price (e.g., $29)" required />
                                <Select required>
                                    <SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger>
                                    <SelectContent>
                                        {Object.entries(categoryData).map(([key, value]) => (
                                            <SelectItem key={key} value={key}>{value}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                                <div>
                                    <label className="text-sm font-medium">Main Product Image</label>
                                    <Input type="file" accept="image/jpeg, image/png, image/webp, image/jpg" className="mt-1" />
                                </div>
                                <div>
                                    <label className="text-sm font-medium">Image Gallery (multiple)</label>
                                    <Input type="file" accept="image/jpeg, image/png, image/webp, image/jpg" multiple className="mt-1" />
                                </div>
                                 <div>
                                    <label className="text-sm font-medium">Videos (multiple)</label>
                                    <Input type="file" accept="video/mp4, image/gif" multiple className="mt-1" />
                                </div>
                                <DialogFooter>
                                    <DialogClose asChild><Button type="submit">Add Product</Button></DialogClose>
                                </DialogFooter>
                            </form>
                        </DialogContent>
                    </Dialog>
                </div>

                <div className="bg-white rounded-lg shadow border border-gray-200">
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                <tr>
                                    <th scope="col" className="px-6 py-3">Product Name</th>
                                    <th scope="col" className="px-6 py-3">Category</th>
                                    <th scope="col" className="px-6 py-3">Price</th>
                                    <th scope="col" className="px-6 py-3 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {products.map(product => (
                                    <tr key={product.id} className="bg-white border-b hover:bg-gray-50">
                                        <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">{product.title}</th>
                                        <td className="px-6 py-4 capitalize">{product.category}</td>
                                        <td className="px-6 py-4">{product.price}</td>
                                        <td className="px-6 py-4 text-right">
                                            <Button variant="ghost" size="icon"><Edit className="h-4 w-4" /></Button>
                                            <Button variant="ghost" size="icon" className="text-red-500"><Trash2 className="h-4 w-4" /></Button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    );
};

export default AdminProductsPage;
