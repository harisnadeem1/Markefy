
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/use-toast';
import { categories as categoryData } from '@/data/products';
import { PlusCircle, Edit, Trash2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";

const AdminCategoriesPage = () => {
    const [categories, setCategories] = useState(Object.entries(categoryData).map(([key, value], i) => ({ id: i, key, name: value })));

    const handleAddCategory = (e) => {
        e.preventDefault();
        toast({ title: "Category added!", description: "The new category has been saved." });
    };

    return (
        <>
            <Helmet><title>Manage Categories</title></Helmet>
            <div>
                <div className="flex justify-between items-center mb-8">
                    <h1 className="text-3xl font-bold text-gray-900">Categories</h1>
                     <Dialog>
                        <DialogTrigger asChild>
                            <Button><PlusCircle className="mr-2 h-4 w-4" /> Add Category</Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[425px]">
                            <DialogHeader>
                                <DialogTitle>Add New Category</DialogTitle>
                                <DialogDescription>Create a new category for products.</DialogDescription>
                            </DialogHeader>
                            <form onSubmit={handleAddCategory} className="grid gap-4 py-4">
                                <Input name="name" placeholder="Category Name" required />
                                <Textarea name="description" placeholder="Category Description" />
                                <div>
                                    <label className="text-sm font-medium">Category Image</label>
                                    <Input type="file" className="mt-1" />
                                </div>
                                <DialogFooter>
                                    <DialogClose asChild><Button type="submit">Add Category</Button></DialogClose>
                                </DialogFooter>
                            </form>
                        </DialogContent>
                    </Dialog>
                </div>
                
                <div className="bg-white rounded-lg shadow border border-gray-200">
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                <tr>
                                    <th scope="col" className="px-6 py-3">Category Name</th>
                                    <th scope="col" className="px-6 py-3">Slug</th>
                                    <th scope="col" className="px-6 py-3 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {categories.map(cat => (
                                    <tr key={cat.id} className="bg-white border-b hover:bg-gray-50">
                                        <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">{cat.name}</th>
                                        <td className="px-6 py-4">{cat.key}</td>
                                        <td className="px-6 py-4 text-right">
                                            <Button variant="ghost" size="icon"><Edit className="h-4 w-4" /></Button>
                                            <Button variant="ghost" size="icon" className="text-red-500"><Trash2 className="h-4 w-4" /></Button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    );
};

export default AdminCategoriesPage;
