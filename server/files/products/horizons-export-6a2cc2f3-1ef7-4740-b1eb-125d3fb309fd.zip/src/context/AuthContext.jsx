
import React, { createContext, useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const storedUser = localStorage.getItem('adminUser');
    try {
        return storedUser ? JSON.parse(storedUser) : null;
    } catch {
        return null;
    }
  });
  
  const navigate = useNavigate();

  const login = (email, password) => {
    if (email === 'admin@example.com' && password === 'admin') {
      const userData = { email };
      localStorage.setItem('adminUser', JSON.stringify(userData));
      setUser(userData);
      navigate('/admin-panel/dashboard');
      return true;
    }
    return false;
  };

  const logout = () => {
    localStorage.removeItem('adminUser');
    setUser(null);
    navigate('/admin-panel/login');
  };

  const value = { user, login, logout };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  return useContext(AuthContext);
};
