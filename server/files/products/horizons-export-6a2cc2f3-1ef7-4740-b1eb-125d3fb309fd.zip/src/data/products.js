export const allProducts = [
  { id: 1, category: 'hero', title: 'Animated Gradient Hero', price: '$29', image: 'Abstract hero section with animated gradient background', tags: ['NEW!', 'HERO SECTION'], rating: 5, description: 'A stunning, lightweight hero section with a beautifully animated gradient that captures attention instantly. Fully responsive and easy to integrate.', features: ['Fully responsive and customizable', 'Lightweight and performance-optimized', 'Adjustable gradient colors and speed', 'Optional text content column', 'Easy to integrate with any project'] },
  { id: 2, category: 'hero', title: 'Hero with Video Background', price: '$35', image: 'Hero section with a video playing in the background', tags: ['With Video', 'HERO SECTION'], rating: 5, description: 'Engage your visitors with a dynamic video background. This component supports local or embedded videos and includes overlay options for text readability.', features: ['Supports YouTube, Vimeo, and local videos', 'Add multiple columns of vertically scrolling media', 'Adjust video playback options', 'Optional text content column', 'Section colors and width within browser'] },
  { id: 3, category: 'carousel', title: 'Infinite Logo Carousel', price: '$19', image: 'A smoothly scrolling carousel of partner logos', tags: ['CAROUSEL & SLIDER'], rating: 4, description: 'Showcase your partners or clients with this seamless, infinite-scrolling logo carousel. It\'s lightweight, CSS-driven, and easy to customize.', features: ['Accepts images & videos', 'Adjust speed and direction', 'Set width of columns', 'Adjust gap between images', 'Colors'] },
  { id: 4, category: 'grid', title: 'Masonry Grid Gallery', price: '$22', image: 'A responsive masonry-style image gallery', tags: ['GALLERY'], description: 'A beautiful, responsive masonry grid that arranges your images in an elegant, Pinterest-like layout. Perfect for portfolios and photo galleries.', features: ['Fully responsive layout', 'Adjustable column counts for different breakpoints', 'Customizable gap between images', 'Image loading animations', 'Optional lightbox integration'] },
  { id: 5, category: 'text-media', title: 'Split-Screen Text & Image', price: '$15', image: 'A section with text on one side and an image on the other', tags: ['TEXT & MEDIA'], rating: 5, description: 'A classic and effective layout to balance descriptive text with compelling imagery. The split-screen adapts beautifully to all screen sizes.', features: ['50/50 or custom split ratios', 'Image on left or right', 'Vertically align content', 'Responsive stacking on mobile', 'Custom background colors'] },
  { id: 6, category: 'effects', title: 'Parallax Scrolling Effect', price: '$25', image: 'An image with a parallax scroll effect', tags: ['NEW!', 'SPECIAL EFFECTS'], description: 'Add depth and a touch of class to your pages with this smooth parallax scrolling effect. It\'s performance-optimized and works on any background image.', features: ['Adjustable parallax speed', 'Works on any background image', 'Performance-optimized', 'Mobile-friendly', 'Easy to apply to any section'] },
  { id: 7, category: 'lite', title: 'Simple Accordion FAQ', price: '$10', image: 'A clean and simple accordion for FAQs', tags: ['LITE VERSION'], rating: 4, description: 'A lightweight and accessible accordion component, perfect for FAQ sections. Cleanly animates on open/close and is fully keyboard navigable.', features: ['Clean and minimal design', 'Smooth animations', 'WCAG 2.1 AA compliant', 'Allows multiple items to be open', 'Customizable icons'] },
  { id: 8, category: 'video', title: 'Video Player with Playlist', price: '$30', image: 'A video player component with a scrollable playlist', tags: ['With Video', 'VIDEO'], description: 'A fully-featured video player that includes a side playlist. Users can easily navigate through your video collection. Supports YouTube, Vimeo, and local files.', features: ['Supports multiple video sources', 'Customizable player controls', 'Autoplay and looping options', 'Responsive playlist layout', 'Remember video progress'] },
  { id: 9, category: 'features', title: 'Feature List with Icons', price: '$18', image: 'A list of features, each with a custom icon', tags: ['HIGHLIGHT FEATURES'], rating: 5, description: 'Clearly present your product\'s key features in a clean list format, each accompanied by a customizable icon to enhance visual communication.', features: ['Custom icon for each feature', 'Multiple layout options (grid, list)', 'Adjustable icon size and color', 'Hover effects', 'Responsive design'] },
  { id: 10, category: 'products', title: 'Product Card with Hover', price: '$20', image: 'An e-commerce product card with a hover effect', tags: ['DISPLAY PRODUCTS'], description: 'An elegant product card for e-commerce sites, featuring a subtle hover effect that reveals more details or an "Add to Cart" button.', features: ['Customizable hover effect', 'Show additional details on hover', 'Quick view button option', 'Star ratings and reviews', 'Sale and "New" badges'] },
  { id: 11, category: 'visitors', title: 'Exit-Intent Popup', price: '$28', image: 'A modal that appears when a user is about to leave the page', tags: ['ATTRACT VISITORS'], rating: 4, description: 'Capture leaving visitors with this smart exit-intent popup. Perfect for promoting special offers or newsletter signups before a user navigates away.', features: ['Adjustable trigger sensitivity', 'Show on a timer or on exit', 'Customizable content and design', 'Cookie-based display frequency', 'Integrates with mailing lists'] },
  { id: 12, category: 'free', title: 'Responsive Social Icons', price: '$0', image: 'A set of social media icons', tags: ['Free'], description: 'A simple and clean set of responsive social media icons. Includes all major platforms and is easy to add to your header or footer.', features: ['Includes 10+ social platforms', 'Multiple icon styles', 'Adjustable size and color', 'Hover effects', 'Easy to add to any part of your site'] },
];

export const categories = {
  all: 'All Snippets',
  hero: 'Hero',
  carousel: 'Carousel & Slideshow',
  grid: 'Grid-Based',
  'text-media': 'Text & Media',
  effects: 'Special Effects',
  lite: 'Lite Version',
  video: 'Video',
  features: 'Highlight Features',
  products: 'Display Products',
  visitors: 'Attract Visitors',
  free: 'Free',
};

export const snippetItems = [
  { title: 'All Snippets', href: '/shop' },
  { title: 'Hero Snippets', href: '/shop/hero' },
  { title: 'Carousel & Slideshow Snippets', href: '/shop/carousel' },
  { title: 'Grid-Based Snippets', href: '/shop/grid' },
  { title: 'Snippets with Text & Media', href: '/shop/text-media' },
  { title: 'Special Effects', href: '/shop/effects' },
  { title: 'Lite Versions', href: '/shop/lite' },
  { title: 'Snippets with Video', href: '/shop/video' },
  { title: 'Highlight Features', href: '/shop/features' },
  { title: 'Display Products', href: '/shop/products' },
  { title: 'Attract Visitors', href: '/shop/visitors' },
  { title: 'Free Snippets', href: '/shop/free' },
];

export const reviews = [
  {
    name: "John D.",
    review: "The Animated Gradient Hero was super easy to install and saved me hours of work. Perfect for my project!",
    product: "Animated Gradient Hero",
    avatar: "Professional male developer with glasses",
    rating: 5
  },
  {
    name: "Sarah M.",
    review: "Amazing quality and documentation on the Masonry Grid. Will definitely buy more snippets!",
    product: "Masonry Grid Gallery",
    avatar: "Female developer with curly hair",
    rating: 5
  },
  {
    name: "Mike R.",
    review: "Clean code, great design, and excellent support for the Exit-Intent Popup. Highly recommended!",
    product: "Exit-Intent Popup",
    avatar: "Young male developer with beard",
    rating: 4
  }
];

export const faqItems = [
    {
        question: "Do I need coding experience?",
        answer: "Our snippets are designed to be beginner-friendly. Basic knowledge of HTML/CSS is helpful, but we provide clear instructions to get you up and running in minutes."
    },
    {
        question: "Can I use this on any website theme?",
        answer: "Yes! Our components are built to be theme-agnostic. They are self-contained and will adopt your existing font styles while maintaining their core design."
    },
    {
        question: "How do I install the snippet?",
        answer: "Installation is simple: 1. You'll receive the code after purchase. 2. Copy the code. 3. Paste it into your website's HTML where you want it to appear. Detailed steps are included."
    },
    {
        question: "What if I need help?",
        answer: "We offer support for all our premium snippets. If you run into any issues, just contact our help desk, and we'll be happy to assist you."
    }
];

export const demoThumbnails = [
    { alt: "Desktop demo view", image: "https://images.unsplash.com/photo-1542363255-5d9858599421" },
    { alt: "Mobile demo view", image: "https://images.unsplash.com/photo-1596704017254-9b1210a83185" },
    { alt: "Alternative desktop layout", image: "https://images.unsplash.com/photo-1542363255-5d9858599421" },
    { alt: "Alternative mobile layout", image: "https://images.unsplash.com/photo-1596704017254-9b1210a83185" },
    { alt: "Customization options view", image: "https://images.unsplash.com/photo-1542363255-5d9858599421" },
];
