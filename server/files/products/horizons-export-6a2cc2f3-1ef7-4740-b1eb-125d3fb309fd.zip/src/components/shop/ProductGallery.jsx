import React from 'react';
import { motion } from 'framer-motion';
import useEmblaCarousel from 'embla-carousel-react';

const ProductGallery = ({ thumbnails }) => {
  const [emblaRef] = useEmblaCarousel({
    align: 'start',
    containScroll: 'trimSnaps',
    loop: true,
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
      className="mt-4"
    >
      <div className="embla" ref={emblaRef}>
        <div className="embla__container">
          {thumbnails.map((thumb, index) => (
            <div className="embla__slide p-2" key={index} style={{ flex: '0 0 20%' }}>
              <div className="aspect-video bg-white rounded-md border-2 border-transparent hover:border-blue-500 transition-colors cursor-pointer p-1">
                <img 
                  class="w-full h-full object-contain rounded-sm"
                  alt={thumb.alt}
                 src="https://images.unsplash.com/photo-1700142909513-63c574cdda3f" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

export default ProductGallery;