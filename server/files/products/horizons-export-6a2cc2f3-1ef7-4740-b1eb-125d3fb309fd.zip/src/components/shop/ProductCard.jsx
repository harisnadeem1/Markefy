
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Star, Video } from 'lucide-react';

const ProductCard = ({ product }) => {
  const handleBuyNow = (e) => {
    e.preventDefault();
    e.stopPropagation();
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  return (
    <Link to={`/product/${product.id}`} className="block">
        <motion.div
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        viewport={{ once: true }}
        className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300 group h-full flex flex-col"
        >
        <div className="relative">
            <img class="h-48 w-full object-cover" alt={product.image} src="https://images.unsplash.com/photo-1687006067259-6de13ca3875e" />
            <div className="absolute top-2 right-2 flex flex-col gap-2">
            {product.tags && product.tags.includes('NEW!') && <span className="bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full">NEW!</span>}
            {product.tags && product.tags.includes('With Video') && <span className="bg-blue-500 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center"><Video className="h-3 w-3 mr-1"/>VIDEO</span>}
            </div>
        </div>
        <div className="p-6 flex flex-col flex-grow">
            <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors flex-grow">{product.title}</h3>
            {product.rating && (
            <div className="flex items-center mb-2">
                {[...Array(5)].map((_, i) => (
                <Star key={i} className={`h-4 w-4 ${i < product.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} />
                ))}
            </div>
            )}
            <div className="flex items-center justify-between mt-4">
            <span className="text-2xl font-bold text-gray-900">{product.price}</span>
            <Button onClick={handleBuyNow} className="bg-blue-600 hover:bg-blue-700">
                Buy Now
            </Button>
            </div>
        </div>
        </motion.div>
    </Link>
  );
};

export default ProductCard;
