import React from 'react';
import { motion } from 'framer-motion';
import { Download, Copy, Palette } from 'lucide-react';

const CategoryIntro = ({ categoryName }) => {
  return (
    <div className="bg-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <h1 className="text-4xl lg:text-5xl font-bold text-gray-900">
            Ready-to-Install <span className="gradient-text">{categoryName}</span>
          </h1>
          <p className="mt-4 max-w-3xl mx-auto text-lg text-gray-600">
            Explore our premium, pre-built {categoryName.toLowerCase()}. Copy, paste, and customize within minutes.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mt-12 grid md:grid-cols-3 gap-8 items-center max-w-4xl mx-auto"
        >
          <div className="flex items-center justify-center md:justify-start">
            <Download className="h-6 w-6 text-blue-500 mr-3" />
            <p><span className="font-bold">1. Get the code</span></p>
          </div>
          <div className="flex items-center justify-center">
            <Copy className="h-6 w-6 text-purple-500 mr-3" />
            <p><span className="font-bold">2. Copy & Paste</span></p>
          </div>
          <div className="flex items-center justify-center md:justify-end">
            <Palette className="h-6 w-6 text-green-500 mr-3" />
            <p><span className="font-bold">3. Customize</span></p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default CategoryIntro;