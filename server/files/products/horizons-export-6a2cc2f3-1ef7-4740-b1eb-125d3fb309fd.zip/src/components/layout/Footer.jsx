
import React from 'react';
import { Link } from 'react-router-dom';
import { toast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Code, Instagram, Facebook, Instagram as Pinterest, Linkedin, Youtube } from 'lucide-react';

const Footer = () => {

  const handleLinkClick = (e) => {
    e.preventDefault();
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const handleSubscribe = (e) => {
    e.preventDefault();
    const email = e.target.email.value;
    if (email) {
      toast({
        title: "🎉 Subscribed!",
        description: `Thank you for subscribing! A 15% discount code has been sent to ${email}.`,
      });
      e.target.email.value = '';
    } else {
      toast({
        title: "Uh oh!",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
    }
  };

  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <span className="text-white font-semibold text-sm uppercase tracking-wider">Company</span>
            <ul className="space-y-2">
              <li><Link to="/about-us" className="hover:text-blue-400 transition-colors">About</Link></li>
              <li><Link to="#" onClick={handleLinkClick} className="hover:text-blue-400 transition-colors">Blog</Link></li>
              <li><Link to="#" onClick={handleLinkClick} className="hover:text-blue-400 transition-colors">Affiliate Program</Link></li>
            </ul>
          </div>

          <div className="space-y-4">
            <span className="text-white font-semibold text-sm uppercase tracking-wider">Help</span>
            <ul className="space-y-2">
              <li><Link to="#" onClick={handleLinkClick} className="hover:text-blue-400 transition-colors">Contact</Link></li>
              <li><Link to="#" onClick={handleLinkClick} className="hover:text-blue-400 transition-colors">Support</Link></li>
              <li><Link to="#" onClick={handleLinkClick} className="hover:text-blue-400 transition-colors">License</Link></li>
              <li><Link to="#" onClick={handleLinkClick} className="hover:text-blue-400 transition-colors">Terms of Service</Link></li>
              <li><Link to="#" onClick={handleLinkClick} className="hover:text-blue-400 transition-colors">Privacy Policy</Link></li>
            </ul>
          </div>

          <div className="col-span-2 md:col-span-2 space-y-4">
            <span className="text-white font-semibold text-sm uppercase tracking-wider">Stay Connected</span>
            <p>Get 15% off your first order when you sign up for our newsletter.</p>
            <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2">
              <Input name="email" type="email" placeholder="Enter your email" className="bg-gray-800 border-gray-700 text-white" />
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700 whitespace-nowrap">Subscribe</Button>
            </form>
          </div>
        </div>

        <div className="mt-12 border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center space-x-2 text-white mb-4 md:mb-0">
              <Code className="h-6 w-6 text-blue-400" />
              <span className="font-bold">CodeSnippets Pro</span>
              <span>© 2025</span>
          </div>
          <div className="flex space-x-6">
            <a href="#" onClick={handleLinkClick} className="text-gray-400 hover:text-white"><Instagram /></a>
            <a href="#" onClick={handleLinkClick} className="text-gray-400 hover:text-white"><Facebook /></a>
            <a href="#" onClick={handleLinkClick} className="text-gray-400 hover:text-white"><Pinterest /></a>
            <a href="#" onClick={handleLinkClick} className="text-gray-400 hover:text-white"><Linkedin /></a>
            <a href="#" onClick={handleLinkClick} className="text-gray-400 hover:text-white"><Youtube /></a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
