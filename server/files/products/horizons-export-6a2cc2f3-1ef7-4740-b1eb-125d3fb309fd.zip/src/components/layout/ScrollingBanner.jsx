
import React from 'react';

const ScrollingBanner = () => {
  const bannerText = "🚀 Special Offer: Get 20% Off All Snippets Today! | Instant Download | Secure Payments | ";
  
  return (
    <div className="bg-blue-600 text-white py-2.5 overflow-hidden relative z-50">
      <div className="whitespace-nowrap">
        <div className="scrolling-text-container inline-block">
          <span className="text-sm font-semibold px-4">{bannerText}</span>
          <span className="text-sm font-semibold px-4">{bannerText}</span>
        </div>
      </div>
    </div>
  );
};

export default ScrollingBanner;
