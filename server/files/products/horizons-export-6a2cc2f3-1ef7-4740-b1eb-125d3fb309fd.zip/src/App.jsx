
import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import ScrollingBanner from '@/components/layout/ScrollingBanner';
import HomePage from '@/pages/HomePage';
import ShopPage from '@/pages/ShopPage';
import CategoryPage from '@/pages/CategoryPage';
import ProductPage from '@/pages/ProductPage';
import CartPage from '@/pages/CartPage';
import CheckoutPage from '@/pages/CheckoutPage';
import OrderConfirmationPage from '@/pages/OrderConfirmationPage';
import NotFoundPage from '@/pages/NotFoundPage';
import AboutUsPage from '@/pages/info/AboutUsPage';
import WhatAreSnippetsPage from '@/pages/info/WhatAreSnippetsPage';
import FaqPage from '@/pages/info/FaqPage';
import CustomRequestPage from '@/pages/request/CustomRequestPage';
import SectionRequestPage from '@/pages/request/SectionRequestPage';
import MigrationPage from '@/pages/request/MigrationPage';
import { CartProvider } from '@/context/CartContext';
import { AuthProvider } from '@/context/AuthContext';
import AdminLayout from '@/components/admin/AdminLayout';
import AdminLoginPage from '@/pages/admin/AdminLoginPage';
import AdminDashboardPage from '@/pages/admin/AdminDashboardPage';
import AdminProductsPage from '@/pages/admin/AdminProductsPage';
import AdminCategoriesPage from '@/pages/admin/AdminCategoriesPage';
import AdminSalesPage from '@/pages/admin/AdminSalesPage';
import ProtectedRoute from '@/components/admin/ProtectedRoute';

function App() {
  const location = useLocation();
  const isCheckoutOrConfirmation = location.pathname.startsWith('/checkout') || location.pathname.startsWith('/order-confirmation');
  const isAdminRoute = location.pathname.startsWith('/admin-panel');

  const MainLayout = ({ children }) => (
    <div className={`flex flex-col ${isCheckoutOrConfirmation ? 'min-h-screen' : 'bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen'}`}>
      {!isCheckoutOrConfirmation && !isAdminRoute && <ScrollingBanner />}
      {!isCheckoutOrConfirmation && !isAdminRoute && <Header />}
      <main className="flex-grow">{children}</main>
      {!isCheckoutOrConfirmation && !isAdminRoute && <Footer />}
    </div>
  );

  return (
    <AuthProvider>
      <CartProvider>
        <Routes>
          {/* Admin Routes */}
          <Route path="/admin-panel/login" element={<AdminLoginPage />} />
          <Route path="/admin-panel" element={<ProtectedRoute><AdminLayout /></ProtectedRoute>}>
            <Route index element={<AdminDashboardPage />} />
            <Route path="dashboard" element={<AdminDashboardPage />} />
            <Route path="products" element={<AdminProductsPage />} />
            <Route path="categories" element={<AdminCategoriesPage />} />
            <Route path="sales" element={<AdminSalesPage />} />
          </Route>

          {/* Main App Routes */}
          <Route path="/*" element={
            <MainLayout>
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/shop" element={<ShopPage />} />
                <Route path="/shop/:category" element={<CategoryPage />} />
                <Route path="/product/:productId" element={<ProductPage />} />
                <Route path="/cart" element={<CartPage />} />
                <Route path="/checkout" element={<CheckoutPage />} />
                <Route path="/order-confirmation" element={<OrderConfirmationPage />} />
                <Route path="/about-us" element={<AboutUsPage />} />
                <Route path="/what-are-code-snippets" element={<WhatAreSnippetsPage />} />
                <Route path="/faq" element={<FaqPage />} />
                <Route path="/custom-request" element={<CustomRequestPage />} />
                <Route path="/section-request" element={<SectionRequestPage />} />
                <Route path="/migration-help" element={<MigrationPage />} />
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            </MainLayout>
          }/>
        </Routes>
        <Toaster />
      </CartProvider>
    </AuthProvider>
  );
}

export default App;
